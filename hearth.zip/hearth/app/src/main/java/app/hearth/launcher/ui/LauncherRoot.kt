package app.hearth.launcher.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.hearth.launcher.LauncherActions
import app.hearth.launcher.LauncherViewModel
import app.hearth.launcher.LockService
import app.hearth.launcher.Slot
import app.hearth.launcher.data.AppEntry
import app.hearth.launcher.data.EmberStore
import app.hearth.launcher.data.GestureAction
import app.hearth.launcher.data.Prefs
import app.hearth.launcher.data.WeatherStore

@Composable
fun LauncherRoot(vm: LauncherViewModel, actions: LauncherActions) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val homeKeys by vm.prefs.home.collectAsStateWithLifecycle()
    val dockKeys by vm.prefs.dock.collectAsStateWithLifecycle()
    val gestures by vm.prefs.gestures.collectAsStateWithLifecycle()
    val columns by vm.prefs.columns.collectAsStateWithLifecycle()
    val lockReady by LockService.running.collectAsStateWithLifecycle()
    val accentSpec by vm.prefs.accent.collectAsStateWithLifecycle()
    val tintIcons by vm.prefs.tintIcons.collectAsStateWithLifecycle()
    val blur by vm.prefs.blur.collectAsStateWithLifecycle()
    val embersOn by vm.prefs.embers.collectAsStateWithLifecycle()
    val coldWeeks by vm.prefs.coldWeeks.collectAsStateWithLifecycle()
    val blurSupported by vm.blurSupported.collectAsStateWithLifecycle()
    val usageAccess by vm.embers.usageAccess.collectAsStateWithLifecycle()
    val lastUsed by vm.embers.lastUsed.collectAsStateWithLifecycle()
    val frequency by vm.embers.frequency.collectAsStateWithLifecycle()
    val drawerOrder by vm.prefs.drawerOrder.collectAsStateWithLifecycle()
    val weatherOn by vm.prefs.weather.collectAsStateWithLifecycle()
    val weather by vm.weather.current.collectAsStateWithLifecycle()
    val byKey = remember(apps) { apps.associateBy { it.key } }

    val appearance = Appearance(accentSpec, tintIcons, blur, embersOn, coldWeeks, drawerOrder, weatherOn)
    fun setAppearance(a: Appearance) {
        val prefs = vm.prefs
        if (a.accent != accentSpec) prefs.setAccent(a.accent)
        if (a.tintIcons != tintIcons) prefs.setTintIcons(a.tintIcons)
        if (a.blur != blur) prefs.setBlur(a.blur)
        if (a.embers != embersOn) prefs.setEmbers(a.embers)
        if (a.coldWeeks != coldWeeks) prefs.setColdWeeks(a.coldWeeks)
        if (a.drawerOrder != drawerOrder) prefs.setDrawerOrder(a.drawerOrder)
        if (a.weather != weatherOn) {
            prefs.setWeather(a.weather)
            vm.refreshWeather(force = true)
        }
    }

    // Every launch through Hearth rekindles the app's ember.
    val launch: (AppEntry) -> Unit = { app ->
        vm.recordLaunch(app.key)
        actions.launch(app)
    }

    val now = remember(lastUsed) { System.currentTimeMillis() }
    val coolOf: (AppEntry) -> Float = { app -> EmberStore.warmth(lastUsed[app.key], now, coldWeeks * 7) }
    val warmth = if (embersOn) coolOf else null

    // Weather: ask for approximate location on the first tap; if refused for good,
    // the next tap leads to Hearth's app settings instead.
    val context = LocalContext.current
    val locale = context.resources.configuration.locales[0]
    var locationGranted by remember { mutableStateOf(vm.weather.hasPermission()) }
    var locationRefused by remember { mutableStateOf(false) }
    LifecycleResumeEffect(Unit) {
        locationGranted = vm.weather.hasPermission()
        onPauseOrDispose { }
    }
    val askLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        locationGranted = granted
        locationRefused = !granted
        if (granted) vm.refreshWeather(force = true)
    }
    val weatherLine: String? = when {
        !weatherOn -> null
        !locationGranted -> if (locationRefused) "Allow location for weather" else "Tap to show the weather"
        else -> weather?.takeIf { System.currentTimeMillis() - it.fetchedAt < WeatherStore.SHOW_FOR_MS }?.line(locale)
    }
    val onWeatherClick = {
        when {
            locationGranted -> vm.refreshWeather(force = true)
            locationRefused -> actions.openAppSettings()
            else -> askLocation.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
    }

    // Decay every score to the same instant so they compare fairly.
    val usageRank: ((AppEntry) -> Float)? = remember(frequency, drawerOrder) {
        val at = System.currentTimeMillis()
        if (drawerOrder == Prefs.ORDER_USAGE) {
            { app: AppEntry -> frequency[app.key]?.valueAt(at) ?: 0f }
        } else {
            null
        }
    }

    // Blur the wallpaper while any full-screen overlay is up.
    val blurring = blur && blurSupported && (vm.drawerOpen || vm.settingsOpen || vm.pickingFor != null)
    val blurRadius by animateIntAsState(if (blurring) 64 else 0, tween(240), label = "blur")
    LaunchedEffect(blurRadius) { actions.setWindowBlur(blurRadius) }
    val scrim = drawerScrim(blurred = blur && blurSupported)

    HearthTheme(accent = rememberAccent(accentSpec), tintIcons = tintIcons) {

        fun perform(action: GestureAction) {
            when (action) {
                GestureAction.None -> Unit
                GestureAction.Drawer -> vm.openDrawer(withKeyboard = false)
                GestureAction.Search -> vm.openDrawer(withKeyboard = true)
                GestureAction.Notifications -> actions.expandNotifications()
                GestureAction.LockScreen -> actions.lockScreen()
                is GestureAction.Launch -> byKey[action.key]?.let(launch)
            }
        }

        fun drawerMenu(app: AppEntry): List<MenuItem> = buildList {
            add(MenuItem(if (app.key in homeKeys) "Remove from home" else "Add to home") { vm.togglePin(app.key) })
            if (app.key in dockKeys) {
                add(MenuItem("Remove from dock") { vm.toggleDock(app.key) })
            } else if (dockKeys.size < LauncherViewModel.DOCK_SIZE) {
                add(MenuItem("Add to dock") { vm.toggleDock(app.key) })
            }
            add(MenuItem("App info") { actions.appInfo(app) })
            if (!app.isSystem) add(MenuItem("Uninstall") { actions.uninstall(app) })
        }

        fun placedMenu(app: AppEntry, slot: Slot): List<MenuItem> = buildList {
            add(MenuItem("Move left") { vm.move(slot, app.key, -1) })
            add(MenuItem("Move right") { vm.move(slot, app.key, +1) })
            when (slot) {
                Slot.Home -> add(MenuItem("Remove from home") { vm.togglePin(app.key) })
                Slot.Dock -> add(MenuItem("Remove from dock") { vm.toggleDock(app.key) })
            }
            add(MenuItem("App info") { actions.appInfo(app) })
            if (!app.isSystem) add(MenuItem("Uninstall") { actions.uninstall(app) })
        }

        Box(Modifier.fillMaxSize()) {
            HomeScreen(
                home = homeKeys.mapNotNull(byKey::get),
                dock = dockKeys.mapNotNull(byKey::get),
                columns = columns,
                onLaunch = launch,
                menuFor = ::placedMenu,
                onGesture = { perform(gestures[it] ?: GestureAction.None) },
                homeMenu = listOf(
                    MenuItem("Wallpaper", actions::openWallpaperPicker),
                    MenuItem("Settings") { vm.settingsOpen = true },
                ),
                onClockClick = actions::openAlarms,
                weather = weatherLine,
                onWeatherClick = onWeatherClick,
            )

            AnimatedVisibility(
                visible = vm.drawerOpen,
                enter = fadeIn() + slideInVertically { it / 5 },
                exit = fadeOut() + slideOutVertically { it / 5 },
            ) {
                AppDrawer(
                    apps = apps,
                    query = vm.query,
                    onQueryChange = { vm.query = it },
                    columns = columns,
                    focusSearch = vm.focusSearch,
                    onAppClick = {
                        launch(it)
                        vm.closeDrawer()
                    },
                    menuFor = ::drawerMenu,
                    onClose = vm::closeDrawer,
                    onOpenSettings = { vm.settingsOpen = true },
                    warmth = warmth,
                    coldWeeks = coldWeeks,
                    scrim = scrim,
                    usageRank = usageRank,
                )
            }

            AnimatedVisibility(
                visible = vm.settingsOpen,
                enter = fadeIn() + slideInHorizontally { it / 4 },
                exit = fadeOut() + slideOutHorizontally { it / 4 },
            ) {
                SettingsScreen(
                    gestures = gestures,
                    labelFor = { byKey[it]?.label },
                    columns = columns,
                    lockReady = lockReady,
                    onGesture = vm::setGesture,
                    onPickApp = { vm.pickingFor = it },
                    onColumns = vm::setColumns,
                    onWallpaper = actions::openWallpaperPicker,
                    onDefaultHome = actions::openHomeSettings,
                    onAccessibility = actions::openAccessibilitySettings,
                    appearance = appearance,
                    onAppearance = ::setAppearance,
                    blurSupported = blurSupported,
                    usageAccess = usageAccess,
                    onUsageAccess = actions::openUsageAccess,
                    onClose = { vm.settingsOpen = false },
                )
            }

            AnimatedVisibility(
                visible = vm.pickingFor != null,
                enter = fadeIn() + slideInVertically { it / 5 },
                exit = fadeOut() + slideOutVertically { it / 5 },
            ) {
                var pickerQuery by remember { mutableStateOf("") }
                AppDrawer(
                    apps = apps,
                    query = pickerQuery,
                    onQueryChange = { pickerQuery = it },
                    columns = columns,
                    focusSearch = false,
                    onAppClick = { app ->
                        vm.pickingFor?.let { vm.setGesture(it, GestureAction.Launch(app.key)) }
                        vm.pickingFor = null
                    },
                    menuFor = null,
                    onClose = { vm.pickingFor = null },
                    title = vm.pickingFor?.let { "${it.label} opens…" },
                    scrim = scrim,
                )
            }
        }
    }
}
